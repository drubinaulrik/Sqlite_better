import express from 'express'
import * as db from './util/database.js'

const app = express()
app.use(express.json())
const PORT = 8080

app.get('/users', (req, res) => {
    const users = db.getUsers()
    res.status(200).json(users)
})

app.listen(PORT, () => {console.log(`Server runs on port ${PORT}`)})